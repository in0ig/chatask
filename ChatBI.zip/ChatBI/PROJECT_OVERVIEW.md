# ChatBI 项目完整指南

## 📋 项目概述

**ChatBI** 是一个智能数据分析对话系统，模仿腾讯云 ChatBI 的核心功能。用户可以通过自然语言与系统对话，快速获取数据分析结果、生成可视化报告。

### 核心特性
- ✅ 自然语言查询（NLQ）- 用户用中文提问，系统自动生成SQL并返回结果
- ✅ 多数据源支持 - MySQL 数据库和 Excel 文件
- ✅ 智能模式切换 - "智能问数"和"生成报告"两种模式
- ✅ 多轮对话 - 支持会话管理和上下文记忆
- ✅ 数据准备 - 数据源管理、数据表配置、字典表维护
- ✅ 权限控制 - 行级和列级权限管理
- ✅ 查询缓存 - 自动缓存查询结果，提升性能

---

## 🚀 快速启动指南

### 前置条件
```bash
# 确保已安装以下软件
- Python 3.12+
- Node.js 18+
- npm 8+
- MySQL 8+
```

### 方式一：使用启动脚本（推荐）

```bash
# 1. 进入项目根目录
cd /Users/zhanh391/PC/ChatBI

# 2. 启动所有服务（自动处理虚拟环境、依赖、数据库）
./scripts/start.sh

# 3. 访问应用
# 前端: http://localhost:3000
# 后端 API: http://localhost:8000
# API 文档: http://localhost:8000/docs

# 4. 停止服务
./scripts/stop.sh
```

### 方式二：手动启动

#### 步骤 1: 创建虚拟环境
```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
```

#### 步骤 2: 初始化数据库
```bash
# 启动 MySQL
brew services start mysql

# 初始化数据库（创建表和初始数据）
mysql -u root < database/init.sql
```

#### 步骤 3: 启动后端服务
```bash
cd backend
uvicorn src.main:app --host 0.0.0.0 --port 8000 --reload
```

#### 步骤 4: 启动前端服务
```bash
cd frontend
npm install
npm run dev
```

---

## 👥 用户流程（User Flow）

### 场景 1: 新用户首次使用

```
1. 用户访问 http://localhost:3000
   ↓
2. 系统显示欢迎界面
   - 左侧导航菜单
   - 中央对话工作台
   - 右侧配置抽屉（默认关闭）
   ↓
3. 用户点击"数据分析" → "数据源"
   ↓
4. 用户创建数据源
   - 输入连接信息（主机、端口、用户名、密码、数据库名）
   - 点击"测试连接"验证
   - 点击"保存"创建数据源
   ↓
5. 系统自动激活新数据源
   ↓
6. 用户返回对话工作台
   ↓
7. 用户在输入框输入问题（如："2024年销售额是多少？"）
   ↓
8. 系统处理查询
   - 解析自然语言
   - 生成 SQL 语句
   - 执行查询
   - 生成图表
   ↓
9. 系统显示结果
   - 左侧显示 AI 回复
   - 包含图表和数据表格
   - 提供刷新、点赞、点踩操作
   ↓
10. 用户可以继续提问或查看历史记录
```

### 场景 2: 用户切换查询模式

```
1. 用户在输入框上方看到"模式切换"开关
   ↓
2. 用户点击开关从"智能问数"切换到"生成报告"
   ↓
3. 系统更新 chatMode 状态
   ↓
4. 用户输入问题
   ↓
5. 系统以"生成报告"模式处理
   - 返回结构化报告
   - 包含多个图表和分析
   ↓
6. 系统显示完整报告
```

### 场景 3: 用户管理权限

```
1. 用户点击右上角"配置"按钮
   ↓
2. 右侧配置抽屉滑出
   ↓
3. 用户点击"权限配置"
   ↓
4. 用户配置：
   - 功能权限（查询、报告、导出）
   - 数据表权限（选择可访问的表）
   ↓
5. 系统保存权限配置
   ↓
6. 后续查询时自动检查权限
```

### 场景 4: 用户查看查询历史

```
1. 用户点击"历史"按钮
   ↓
2. 系统显示历史查询列表
   - 查询文本
   - 查询时间
   - 结果摘要
   ↓
3. 用户点击历史项
   ↓
4. 系统重新加载该查询结果（从缓存）
   ↓
5. 用户可以修改查询或继续提问
```

---

## 🔄 数据流程（Data Flow）

### 整体架构

```
┌─────────────────────────────────────────────────────────┐
│                     前端层 (Vue 3)                        │
│  ┌──────────────────────────────────────────────────┐  │
│  │ 用户界面                                          │  │
│  │ - NavigationSidebar (左侧导航)                    │  │
│  │ - ChatInterface (对话工作台)                      │  │
│  │ - ConfigDrawer (配置抽屉)                         │  │
│  └──────────────────────────────────────────────────┘  │
│                        ↓                                 │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Pinia Store (状态管理)                            │  │
│  │ - chat.ts (对话状态)                              │  │
│  │ - ui.ts (UI 状态)                                 │  │
│  │ - dataPrep.ts (数据准备状态)                      │  │
│  └──────────────────────────────────────────────────┘  │
│                        ↓                                 │
│  ┌──────────────────────────────────────────────────┐  │
│  │ 工具函数                                          │  │
│  │ - debounce.ts (防抖)                              │  │
│  │ - throttle.ts (节流)                              │  │
│  │ - cache.ts (缓存)                                 │  │
│  └──────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
                        ↓ HTTP/REST
┌─────────────────────────────────────────────────────────┐
│                   后端层 (FastAPI)                        │
│  ┌──────────────────────────────────────────────────┐  │
│  │ API 路由                                          │  │
│  │ - /api/query (查询处理)                           │  │
│  │ - /api/sessions (会话管理)                        │  │
│  │ - /api/datasources (数据源管理)                   │  │
│  │ - /api/data-prep (数据准备)                       │  │
│  │ - /api/history (历史记录)                         │  │
│  └──────────────────────────────────────────────────┘  │
│                        ↓                                 │
│  ┌──────────────────────────────────────────────────┐  │
│  │ 业务逻辑层                                        │  │
│  │ - QueryService (查询处理)                         │  │
│  │ - SessionService (会话管理)                       │  │
│  │ - DataSourceService (数据源管理)                  │  │
│  │ - DatabaseService (数据库连接)                    │  │
│  └──────────────────────────────────────────────────┘  │
│                        ↓                                 │
│  ┌──────────────────────────────────────────────────┐  │
│  │ 配置管理                                          │  │
│  │ - config.py (环境变量配置)                        │  │
│  │ - .env (配置文件)                                 │  │
│  └──────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
                        ↓ SQL
┌─────────────────────────────────────────────────────────┐
│                   数据层 (MySQL)                          │
│  ┌──────────────────────────────────────────────────┐  │
│  │ 数据库表                                          │  │
│  │ - users (用户表)                                  │  │
│  │ - data_sources (数据源表)                         │  │
│  │ - query_sessions (会话表)                         │  │
│  │ - query_history (查询历史表)                      │  │
│  │ - dictionary_table (字典表)                       │  │
│  └──────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
```

### 查询流程详解

```
用户输入查询
    ↓
[前端] 用户在输入框输入问题
    ↓
[前端] 点击发送按钮
    ↓
[前端] Chat Store 检查缓存
    ├─ 缓存命中 → 直接返回缓存结果 → 显示结果
    └─ 缓存未命中 → 继续
    ↓
[前端] 构建请求 Payload
    {
      "text": "2024年销售额是多少？",
      "session_id": "session_123",
      "data_source_id": "ds_1",
      "mode": "query"  // 或 "report"
    }
    ↓
[前端] 发送 POST /api/query 请求
    ↓
[后端] QueryService 接收请求
    ↓
[后端] NLU 模块解析自然语言
    - 识别意图（查询、报告等）
    - 提取实体（时间、指标等）
    - 识别数据源
    ↓
[后端] SQL 生成模块
    - 根据解析结果生成 SQL
    - 示例: SELECT SUM(amount) FROM sales WHERE year=2024
    ↓
[后端] 权限检查
    - 检查用户是否有权访问该表
    - 检查行级权限
    - 检查列级权限
    ↓
[后端] DatabaseService 执行 SQL
    - 从连接池获取连接
    - 执行 SQL 查询
    - 返回结果集
    ↓
[后端] 结果处理
    - 格式化数据
    - 推断图表类型
    - 生成摘要文本
    ↓
[后端] 返回响应
    {
      "result": {
        "data": [...],
        "chart_type": "bar",
        "explanation": "2024年销售额为..."
      }
    }
    ↓
[前端] Chat Store 接收响应
    ↓
[前端] 缓存查询结果
    - 使用 "查询文本|数据源ID" 作为键
    - 存储结果和时间戳
    ↓
[前端] 添加消息到消息流
    - 用户消息（右侧）
    - AI 响应（左侧，包含图表）
    ↓
[前端] 显示结果给用户
    - 渲染图表
    - 显示数据表格
    - 提供操作按钮（刷新、点赞、点踩）
```

### 数据源管理流程

```
用户创建数据源
    ↓
[前端] 用户填写连接信息
    {
      "name": "销售数据库",
      "type": "mysql",
      "host": "localhost",
      "port": 3306,
      "user": "root",
      "password": "***",
      "database": "sales_db"
    }
    ↓
[前端] 用户点击"测试连接"
    ↓
[前端] 发送 POST /api/datasources/test
    ↓
[后端] DataSourceService 测试连接
    - 使用提供的配置创建临时连接
    - 执行简单查询验证
    - 返回测试结果
    ↓
[前端] 根据测试结果
    ├─ 成功 → 启用"保存"按钮，显示成功提示
    └─ 失败 → 禁用"保存"按钮，显示错误提示
    ↓
[前端] 用户点击"保存"
    ↓
[前端] 发送 POST /api/datasources
    ↓
[后端] 保存数据源配置到数据库
    ↓
[前端] DataPrep Store 更新数据源列表
    ↓
[前端] 自动激活新数据源
    ↓
[前端] 显示成功提示
```

### 会话管理流程

```
用户创建新会话
    ↓
[前端] 用户点击"新建会话"
    ↓
[前端] 发送 POST /api/sessions
    {
      "user_id": 1,
      "session_id": null,
      "conversation": []
    }
    ↓
[后端] SessionService 创建会话
    - 生成唯一 session_id
    - 初始化空的 conversation 数组
    - 保存到数据库
    ↓
[前端] Chat Store 更新当前会话
    - 设置 currentSessionId
    - 清空消息列表
    ↓
[前端] 显示新会话
    - 显示欢迎语
    - 显示推荐问题
    ↓
用户发送消息
    ↓
[前端] 消息添加到 messages 数组
    ↓
[后端] 消息保存到 query_sessions 表
    - 更新 conversation JSON 字段
    - 更新 last_active 时间戳
    ↓
[前端] 消息显示在对话流中
```

### 缓存机制

```
查询缓存键生成
    ↓
缓存键 = "查询文本|数据源ID"
示例: "2024年销售额是多少？|ds_1"
    ↓
查询时检查缓存
    ├─ 缓存存在 → 直接返回缓存结果（无需调用后端）
    └─ 缓存不存在 → 调用后端 API
    ↓
后端返回结果后
    ↓
[前端] 将结果存储到缓存
    {
      "2024年销售额是多少？|ds_1": {
        "result": {...},
        "timestamp": 2026-01-16T...
      }
    }
    ↓
缓存优势
    - 减少网络请求
    - 提升响应速度
    - 降低后端负载
```

---

## 📊 状态管理（Pinia Stores）

### Chat Store (chat.ts)

**职责**: 管理对话相关的所有状态

**关键状态**:
```typescript
{
  currentSessionId: string | null,      // 当前会话 ID
  sessions: Session[],                  // 所有会话列表
  messages: Message[],                  // 当前会话的消息
  inputText: string,                    // 输入框文本
  currentDataSource: string | null,     // 当前选中的数据源
  chatMode: 'query' | 'report',         // 对话模式
  recommendedQuestions: string[],       // 推荐问题列表
  queryHistory: QueryHistory[],         // 查询历史
  queryCache: Map<string, CachedResult> // 查询缓存
}
```

**关键方法**:
- `sendMessage()` - 发送查询
- `createSession()` - 创建新会话
- `switchSession()` - 切换会话
- `toggleChatMode()` - 切换模式
- `clearMessages()` - 清空消息
- `loadHistory()` - 加载历史记录

### UI Store (ui.ts)

**职责**: 管理 UI 相关的全局状态

**关键状态**:
```typescript
{
  isConfigDrawerOpen: boolean,           // 配置抽屉是否打开
  isReportTemplateModalOpen: boolean,    // 报告模板 Modal
  isKnowledgeBaseModalOpen: boolean,     // 知识库 Modal
  isLoading: boolean,                    // 是否加载中
  loadingMessage: string,                // 加载消息
  toastMessage: string,                  // Toast 消息
  toastType: 'success' | 'error' | ...,  // Toast 类型
  isSidebarCollapsed: boolean            // 侧边栏是否折叠
}
```

**关键方法**:
- `toggleConfigDrawer()` - 切换配置抽屉
- `setLoading()` - 设置加载状态
- `showToast()` - 显示 Toast 通知
- `openReportTemplateModal()` - 打开报告模板 Modal

### DataPrep Store (dataPrep.ts)

**职责**: 管理数据准备相关的状态

**关键状态**:
```typescript
{
  dataSources: DataSource[],             // 数据源列表
  activeDataSourceId: string | null,     // 活跃数据源 ID
  dataTables: DataTable[],               // 数据表列表
  dictionaries: DictionaryEntry[],       // 字典表
  permissions: {...},                    // 权限配置
  tablePermissions: string[],            // 表级权限
  dataSourceCache: {...}                 // 数据源缓存
}
```

**关键方法**:
- `loadDataSources()` - 加载数据源（带缓存）
- `createDataSource()` - 创建数据源
- `testConnection()` - 测试连接
- `activateDataSource()` - 激活数据源
- `loadDictionaries()` - 加载字典表
- `mapValue()` - 字典值映射

---

## 🔌 API 端点

### 查询相关
- `POST /api/query` - 发送查询
- `GET /api/query/history` - 获取查询历史
- `DELETE /api/query/history` - 清空历史

### 会话相关
- `GET /api/sessions` - 获取所有会话
- `POST /api/sessions` - 创建会话
- `PUT /api/sessions/{id}` - 更新会话
- `DELETE /api/sessions/{id}` - 删除会话

### 数据源相关
- `GET /api/datasources` - 获取数据源列表
- `POST /api/datasources` - 创建数据源
- `PUT /api/datasources/{id}` - 更新数据源
- `DELETE /api/datasources/{id}` - 删除数据源
- `POST /api/datasources/test` - 测试连接
- `PUT /api/datasources/{id}/activate` - 激活数据源
- `POST /api/datasources/upload` - 上传 Excel

### 数据准备相关
- `GET /api/data-prep/tables` - 获取数据表
- `POST /api/data-prep/tables/{id}/sync` - 同步表结构
- `GET /api/data-prep/dictionaries` - 获取字典表
- `POST /api/data-prep/dictionaries` - 创建字典条目
- `PUT /api/data-prep/dictionaries/{id}` - 更新字典条目
- `DELETE /api/data-prep/dictionaries/{id}` - 删除字典条目

---

## 🗄️ 数据库表结构

### users 表
```sql
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### data_sources 表
```sql
CREATE TABLE data_sources (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type ENUM('mysql', 'excel', 'api') NOT NULL,
    connection_string TEXT,
    file_path VARCHAR(255),
    is_active BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### query_sessions 表
```sql
CREATE TABLE query_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    session_id VARCHAR(100) NOT NULL,
    conversation JSON,
    last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
```

### query_history 表
```sql
CREATE TABLE query_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    query_text TEXT NOT NULL,
    generated_sql TEXT,
    chart_type VARCHAR(50),
    result_data JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
```

### dictionary_table 表
```sql
CREATE TABLE dictionary_table (
    id INT AUTO_INCREMENT PRIMARY KEY,
    table_name VARCHAR(100) NOT NULL,
    field_name VARCHAR(100) NOT NULL,
    value VARCHAR(100) NOT NULL,
    label VARCHAR(100) NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_entry (table_name, field_name, value)
);
```

---

## 🔧 环境变量配置

创建 `backend/.env` 文件：

```env
# 数据库配置
DB_HOST=127.0.0.1
DB_PORT=3306
DB_USER=root
DB_PASSWORD=12345678
DB_NAME=chatbi
DB_POOL_SIZE=5

# 模型配置
MODEL_TYPE=local
QWEN_MODEL_NAME=qwen-agent

# 应用配置
LOG_LEVEL=INFO
DEBUG=false
```

---

## 📁 项目结构

```
ChatBI/
├── backend/                    # 后端服务
│   ├── src/
│   │   ├── main.py            # 应用入口
│   │   ├── config.py          # 配置管理
│   │   ├── api/               # API 路由
│   │   ├── services/          # 业务逻辑
│   │   ├── models/            # 数据模型
│   │   └── utils/             # 工具函数
│   ├── tests/                 # 测试文件
│   ├── .venv/                 # 虚拟环境
│   ├── pyproject.toml         # 项目配置
│   └── .env                   # 环境变量
│
├── frontend/                  # 前端应用
│   ├── src/
│   │   ├── App.vue            # 根组件
│   │   ├── main.ts            # 入口文件
│   │   ├── components/        # 组件
│   │   ├── views/             # 页面
│   │   ├── store/             # Pinia Store
│   │   ├── router/            # 路由
│   │   ├── utils/             # 工具函数
│   │   └── styles/            # 样式
│   ├── tests/                 # 测试文件
│   ├── package.json           # 依赖配置
│   ├── vite.config.ts         # Vite 配置
│   └── vitest.config.ts       # Vitest 配置
│
├── database/                  # 数据库
│   └── init.sql              # 初始化脚本
│
├── scripts/                   # 启动脚本
│   ├── start.sh              # 启动脚本
│   └── stop.sh               # 停止脚本
│
├── .kiro/                     # Kiro 配置
│   ├── specs/                # 项目规范
│   └── steering/             # 开发指南
│
├── README.md                  # 项目说明
├── IFLOW.md                   # iFlow 说明
├── DEPLOYMENT.md              # 部署指南
└── PROJECT_OVERVIEW.md        # 本文件
```

---

## 🧪 测试

### 运行前端测试
```bash
cd frontend
npm run test -- --run
```

### 运行后端测试
```bash
cd backend
python -m pytest tests/
```

### 运行集成测试
```bash
cd backend
python -m pytest tests/integration/integration_test.py
```

---

## 📝 常见问题

### Q: 启动时提示"虚拟环境不存在"
A: 运行以下命令创建虚拟环境：
```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
```

### Q: 数据库连接失败
A: 检查以下几点：
1. MySQL 服务是否运行：`brew services start mysql`
2. 数据库是否初始化：`mysql -u root < database/init.sql`
3. 环境变量是否正确：检查 `backend/.env`

### Q: 前端无法访问后端 API
A: 检查 `frontend/vite.config.ts` 中的代理配置是否正确指向 `http://localhost:8000`

### Q: 查询返回权限错误
A: 检查用户权限配置：
1. 打开右侧配置抽屉
2. 点击"权限配置"
3. 确保用户有权访问该表

---

## 🎯 下一步

1. **部署到生产环境** - 参考 `DEPLOYMENT.md`
2. **集成 Qwen 模型** - 配置 `MODEL_TYPE=cloud` 和 `QWEN_API_KEY`
3. **添加更多数据源** - 支持 PostgreSQL、Oracle 等
4. **性能优化** - 启用 Redis 缓存、数据库索引优化
5. **用户认证** - 集成 OAuth 或 JWT 认证

---

**最后更新**: 2026-01-16  
**版本**: 1.0  
**状态**: 生产就绪 ✅
